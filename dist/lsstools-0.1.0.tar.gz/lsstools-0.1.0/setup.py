from setuptools import setup

setup(
    name='lsstools',
    version='0.1.0',
    description='A package for working with LSS load files',
    author='Harry Bonshor-Mayes',
    author_email='harrybonshormayes@gmail.com',
    py_modules=['lsstools'],
    install_requires=[],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
)
